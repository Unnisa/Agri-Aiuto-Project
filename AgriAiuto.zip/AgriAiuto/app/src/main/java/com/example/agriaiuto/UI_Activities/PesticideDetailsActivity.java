package com.example.agriaiuto.UI_Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.agriaiuto.R;
import com.squareup.picasso.Picasso;

public class PesticideDetailsActivity extends AppCompatActivity {
    TextView tv_name,tv_cost,tv_des,tv_modeOfAction,tv_features,tv_chemicalsUsed,tv_getHowtoUse;
    ImageView img_pesticides_details;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pesticide_details);

        img_pesticides_details = findViewById(R.id.imageview_pesticide_details);
        tv_name = findViewById(R.id.tv_pesticide_name_details);
        tv_cost = findViewById(R.id.tv_pesticide_description_details);
        tv_modeOfAction = findViewById(R.id.tv_pesticide_modeofAction_details);
        tv_features = findViewById(R.id.tv_pesticide_features_details);
        tv_chemicalsUsed = findViewById(R.id.tv_pesticide_chemicals_details);
        tv_getHowtoUse = findViewById(R.id.tv_pesticide_howToUse_details);

        String name = getIntent().getStringExtra("pesticideNameKey");
        String img = getIntent().getStringExtra("pesticideImageKey");
        String cost = getIntent().getStringExtra("pesticideCostKey");
        String des = getIntent().getStringExtra("pesticideDesKey");
        String modeOfAction = getIntent().getStringExtra("pesticideModeOfActionKey");
        String features = getIntent().getStringExtra("pesticideFeaturesKey");
        String chemicals = getIntent().getStringExtra("pesticideChemicalsKey");
        String howToUse = getIntent().getStringExtra("pesticideHowToUsedKey");

        if (img.isEmpty()) {
            img_pesticides_details.setImageResource(R.mipmap.ic_launcher);
        } else {
            Picasso.with(this)
                    .load(img)
                    .into(img_pesticides_details);
        }

        if (name !=null){
            tv_name.setText(name);
        } else {
            tv_name.setText("No Name Available for this");

        }
       /*  if (cost !=null){
            tv_cost.setText(cost);
         } else {
             tv_cost.setText("no cost Available");
         }
       */
       /*if (des !=null){
                      tv_des.setText(des);
         } else {
         tv_des.setText("description not availble");
         }
       */
       if (features !=null){
             tv_features.setText(features);
         } else {
         tv_features.setText("no features available for this pesticide");
         }
         if (modeOfAction !=null){
          tv_modeOfAction.setText(modeOfAction);
         }
         else {
            tv_modeOfAction.setText("no ModeOfAction");
         }
         if (chemicals !=null){
             tv_chemicalsUsed.setText(chemicals);

         } else {
             tv_chemicalsUsed.setText("no Chemicals used");
         }
         if (howToUse !=null){
             tv_getHowtoUse.setText(howToUse);
         } else {
             tv_getHowtoUse.setText("No data for how to use");

         }
    }
}
