package com.example.agriaiuto.Fragments;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.agriaiuto.Adapters.CropAdapter;
import com.example.agriaiuto.Model.CropModel;
import com.example.agriaiuto.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class CropFragment extends Fragment {
    private RecyclerView recyclerView;
    private DatabaseReference myref;
    private String language;
    ProgressDialog pg;

    SharedPreferences sp;
    private static final String spFile = "com.example.agriaiuto.UI_Activities.spFile";
    SharedPreferences.Editor editor;
    private List<CropModel> cropModelArrayList;

    @SuppressLint("ValidFragment")
    public CropFragment(String language) {
        this.language = language;
    }

    public CropFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_crop, container, false);
        recyclerView = v.findViewById(R.id.recycler_crop_frag);
      //  FirebaseDatabase.getInstance().setPersistenceEnabled(true);

        cropModelArrayList = new ArrayList<>();

        language = getActivity().getIntent().getStringExtra("KEY");
        pg = new ProgressDialog(getActivity());
        pg.setMessage("Crop Data Loading...\nPlease Wait");
        pg.show();

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

       /* if(sp != null) {
            language = sp.getString("languageKey","l");
            Toast.makeText(getActivity(), language, Toast.LENGTH_SHORT).show();
        }
       */
        myref = FirebaseDatabase.getInstance().getReferenceFromUrl("https://agri-aiuto.firebaseio.com/crop/" + language);
        myref.keepSynced(true);
       /* FirebaseRecyclerAdapter<CropModel, CropFragment.CropInfoViewHolder> recyclerAdapter = new FirebaseRecyclerAdapter<CropModel, CropFragment.CropInfoViewHolder>(
                CropModel.class,
                R.layout.row_crop,
                CropFragment.CropInfoViewHolder.class,
                myref
        ) {
            @Override
            protected void populateViewHolder(CropFragment.CropInfoViewHolder viewHolder, final CropModel model, int position) {
                viewHolder.setTitle(model.getName());
                viewHolder.setImage(model.getImageLink());
                pg.dismiss();
                viewHolder.cv.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(getContext(), Crop_DetailsActivity.class);
                        i.putExtra("amountOfWaterKey", model.getAmountOfWater());
                        i.putExtra("desKey", model.getDescrption());
                        i.putExtra("imageLinkKey", model.getImageLink());
                        i.putExtra("nameKey", model.getName());
                        i.putExtra("pesticidesKey", model.getPesticides());
                        i.putExtra("seasonKey", model.getPesticides());
                        i.putExtra("soilTypeKey", model.getSoilType());
                        i.putExtra("temperatureKey", model.getTemperature());
                        startActivity(i);
                    }
                });
            }
        };
        recyclerView.setAdapter(recyclerAdapter);
*/
        myref.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                Toast.makeText(getContext(), ""+dataSnapshot.getChildrenCount(), Toast.LENGTH_SHORT).show();

                for (DataSnapshot ds:dataSnapshot.getChildren())
                {
                    CropModel upload=ds.getValue(CropModel.class);
                    cropModelArrayList.add(upload);
                }

                Log.i("mylog:",""+cropModelArrayList.size());
                //recyclerView.setAdapter(new CropAdapter(getContext(),cropModelArrayList));
                recyclerView.setAdapter(new CropAdapter(getContext(),cropModelArrayList,recyclerView));

                pg.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        });


        return v;
    }


    /*public static class CropInfoViewHolder extends RecyclerView.ViewHolder {
        View mView;
        TextView textView_title;
        ImageView imageView;
        CardView cv;

        public CropInfoViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            textView_title = itemView.findViewById(R.id.seedName);
            imageView = itemView.findViewById(R.id.seedImageview);
            cv = itemView.findViewById(R.id.cardview_crop);

        }

        public void setTitle(String title) {
            textView_title.setText(title + "");
        }

        public void setImage(String image) {
            if (image.isEmpty()) {
                imageView.setImageResource(R.mipmap.ic_launcher);
            } else {
                Picasso.with(mView.getContext())
                        .load(image)
                        .into(imageView);
            }
        }
    }
*/
}
