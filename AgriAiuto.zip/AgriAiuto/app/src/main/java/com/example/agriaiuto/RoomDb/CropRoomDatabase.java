package com.example.agriaiuto.RoomDb;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

import com.example.agriaiuto.Model.CropModel;

@Database(entities = {CropModel.class},version = 1,exportSchema = false)
public abstract class CropRoomDatabase extends RoomDatabase
{

    private static final String DATABASE = "crop_database";

    public abstract CropDao mCropDao();

    private static volatile CropRoomDatabase INSTANCE;

    static CropRoomDatabase getDatabase(final Context context) {
        if (INSTANCE == null) {
            synchronized (CropRoomDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                            CropRoomDatabase.class, DATABASE)
                            .allowMainThreadQueries()
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;

    }



}
