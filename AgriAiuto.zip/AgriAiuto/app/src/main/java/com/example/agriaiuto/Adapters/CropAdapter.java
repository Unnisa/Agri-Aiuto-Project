package com.example.agriaiuto.Adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.agriaiuto.Model.CropModel;
import com.example.agriaiuto.R;
import com.example.agriaiuto.UI_Activities.Crop_DetailsActivity;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

public class CropAdapter extends RecyclerView.Adapter<CropAdapter.CropInfo>
{
    private Context context;
    List<CropModel> arrayList;
    RecyclerView rv;

    public CropAdapter(Context context, List<CropModel> arrayList, RecyclerView rv) {
        this.context = context;
        this.arrayList = arrayList;
        this.rv = rv;
    }
    /*public CropAdapter(Context context, ArrayList<CropModel> arrayList)
    {
        this.context = context;
        this.arrayList = arrayList;
    }*/

    @NonNull
    @Override
    public CropInfo onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(context).inflate(R.layout.row_crop,viewGroup,false);
        return new CropInfo(v);
    }

    @Override
    public void onBindViewHolder(@NonNull CropInfo cropInfo, final int p) {
        cropInfo.setTitle(arrayList.get(p).getName());
        cropInfo.setImage(arrayList.get(p).getImageLink());

        cropInfo.cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(context, Crop_DetailsActivity.class);
                i.putExtra("amountOfWaterKey", arrayList.get(p).getAmountOfWater());
                i.putExtra("desKey", arrayList.get(p).getDescrption());
                i.putExtra("imageLinkKey", arrayList.get(p).getImageLink());
                i.putExtra("nameKey", arrayList.get(p).getName());
                i.putExtra("pesticidesKey", arrayList.get(p).getPesticides());
                i.putExtra("seasonKey", arrayList.get(p).getPesticides());
                i.putExtra("soilTypeKey",arrayList.get(p).getSoilType());
                i.putExtra("temperatureKey", arrayList.get(p).getTemperature());
                context.startActivity(i);

            }
        });
    }

    @Override
    public int getItemCount() {
        return arrayList.size();
    }

    public class CropInfo extends RecyclerView.ViewHolder {
        View mView;
        TextView textView_title;
        ImageView imageView;
        CardView cv;

        public CropInfo(View itemView) {
            super(itemView);
            mView = itemView;
            textView_title = itemView.findViewById(R.id.seedName);
            imageView = itemView.findViewById(R.id.seedImageview);
            cv = itemView.findViewById(R.id.cardview_crop);

        }

        public void setTitle(String title) {
            textView_title.setText(title + "");
        }

        public void setImage(String image) {
            if (image.isEmpty()) {
                imageView.setImageResource(R.mipmap.ic_launcher);
            } else {
                Picasso.with(mView.getContext())
                        .load(image)
                        .into(imageView);
            }
        }
    }

}
