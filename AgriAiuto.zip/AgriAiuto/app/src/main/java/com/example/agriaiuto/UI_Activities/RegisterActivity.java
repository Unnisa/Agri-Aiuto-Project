package com.example.agriaiuto.UI_Activities;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.agriaiuto.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

public class RegisterActivity extends AppCompatActivity {
    TextInputEditText mail,pass,name;
    FirebaseAuth mAuth;
    ProgressDialog pg;
    private DatabaseReference databaseReference;
    private DatabaseReference userIdRef;

    SharedPreferences sp;
    SharedPreferences.Editor editor;
    private static final String spFile = "com.example.agriaiuto.UI_Activities.spFile";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        name = findViewById(R.id.et_name);
        mail = findViewById(R.id.et_mail);
        pass = findViewById(R.id.et_pass);
        sp = getSharedPreferences(spFile,MODE_PRIVATE);

        mAuth = FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("AgriAuito_users");

        pg = new ProgressDialog(this);
        pg.setMessage("Registering..\nPlease wait");
    }

    public void register(View view) {
        userRegister();
    }

    private void userRegister() {
        final String reg_name = name.getText().toString().trim();
        String reg_mail = mail.getText().toString().trim();
        String reg_pass = pass.getText().toString().trim();

        if (reg_name.isEmpty()){
            name.setError("Username Must Be Given");
            name.requestFocus();
        }
        if (reg_mail.isEmpty()){
            mail.setError("Email ID Must Be Given");
            mail.requestFocus();
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(reg_mail).matches()) {
            mail.setError("Please Enter a Valid Email");
            mail.requestFocus();
            return;
        }
        if (reg_pass.isEmpty()){
            pass.setError("Password Must Not Be Empty");
            pass.requestFocus();
        }

        if (reg_pass.length()<6 ) {
            pass.setError("Password Length atleast 6 digits");
            pass.requestFocus();
            return;
        }

        pg.show();

        mAuth.createUserWithEmailAndPassword(reg_mail,reg_pass)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @SuppressLint("NewApi")
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                pg.dismiss();

                userIdRef = databaseReference.child(Objects.requireNonNull(mAuth.getCurrentUser()).getUid());
                userIdRef.child("name").setValue(reg_name);
                editor = sp.edit();
                editor.putString("uNameKey",reg_name);
                editor.commit();

                Intent i = new Intent(RegisterActivity.this, LanguagesActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP & Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                Toast.makeText(RegisterActivity.this, "Registered Successflly", Toast.LENGTH_SHORT).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), "please Enter Correct Credentials", Toast.LENGTH_SHORT).show();
            }
        });

    }
}
