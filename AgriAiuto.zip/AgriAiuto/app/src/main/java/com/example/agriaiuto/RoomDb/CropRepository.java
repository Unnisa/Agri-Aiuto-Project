package com.example.agriaiuto.RoomDb;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import com.example.agriaiuto.Model.CropModel;

import java.util.List;

public class CropRepository
{

    private CropDao mCropDao;
    private LiveData<List<CropModel>> mAllCropData;
    private List<CropModel> cropList;

    CropRepository(Application application) {
        CropRoomDatabase db = CropRoomDatabase.getDatabase(application);
        mCropDao = db.mCropDao();
        mAllCropData = mCropDao.readAllData_liveData();
        cropList = mCropDao.readAllData();
    }

    public LiveData<List<CropModel>> getmAllCropData()
    {
        return mAllCropData;
    }

    public List<CropModel> getCropList() {
        return cropList;
    }

    void insert(CropModel cropEntity) {
        new InsertAsyncTask(mCropDao).execute(cropEntity);
    }
    void delete(CropModel cropEntity)
    {
        new DeleteAsyncTask(mCropDao).execute(cropEntity);
    }


    private static class InsertAsyncTask extends AsyncTask<CropModel,Void,Void>
    {
        private CropDao cropDao;

        private InsertAsyncTask(CropDao cropDao)
        {
            this.cropDao = cropDao;
        }

        @Override
        protected Void doInBackground(CropModel... cropModels) {

            cropDao.saveAsFavourites(cropModels[0]);
            return null;
        }
    }

    private static class DeleteAsyncTask extends AsyncTask<CropModel,Void,Void> {
        private CropDao cropDao;

        private DeleteAsyncTask(CropDao cropDao)
        {
            this.cropDao = cropDao;
        }

        @Override
        protected Void doInBackground(CropModel... cropModels)
        {
            cropDao.removeFromFavourites(cropModels[0]);
            return null;
        }
    }
}
