package com.example.agriaiuto.UI_Activities;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.agriaiuto.Model.Upload;
import com.example.agriaiuto.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.Objects;

public class ImagePickingActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView imageView;
    private ProgressBar pb;
    private Button mButton_ImageUpload, mButton_ChooseImage;
    private EditText mEditText_FileName;
    private StorageTask mUploadtask;


    private Uri mImageUri;

    private StorageReference mStorageRef;
    private DatabaseReference mDatabaseRef;
    private ProgressDialog dialog;

    FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    private DatabaseReference userIdRef;

    String spUserName;
    SharedPreferences sp;
    private static final String spFile = "com.example.agriaiuto.UI_Activities.spFile";


    @SuppressLint("NewApi")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_picking);
        mButton_ChooseImage = findViewById(R.id.img_choose_btn);
        mButton_ImageUpload = findViewById(R.id.upload_btn);
        mEditText_FileName = findViewById(R.id.editText_img_title);
        pb = findViewById(R.id.progress_bar);
        imageView = findViewById(R.id.imageView);

        dialog=new ProgressDialog(this);
        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        dialog.setTitle("image uploading");
        dialog.setMessage("please wait");

        if (sp != null)
        {
            spUserName = sp.getString("uNameKey","a");
        }


        mAuth=FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("AgriAuito_users")
                .child(Objects.requireNonNull(mAuth.getCurrentUser()).getUid()).child("name");


        mStorageRef = FirebaseStorage.getInstance().getReference("uploads");
        mDatabaseRef = FirebaseDatabase.getInstance().getReferenceFromUrl("https://agri-aiuto.firebaseio.com/uploads");



        mButton_ChooseImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                openFileChooser();
            }
        });
        mButton_ImageUpload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mUploadtask!=null && mUploadtask.isInProgress())
                {
                    dialog.show();
                    Toast.makeText(ImagePickingActivity.this, "UPLOAD IN PROGRESS", Toast.LENGTH_SHORT).show();
                }
                else {
                    dialog.show();
                    uploadFile();


                }
            }
        });


    }

    private String getFileExtension(Uri uri) {
        ContentResolver cr = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();

        return mime.getExtensionFromMimeType(cr.getType(uri));
    }

    private void uploadFile() {

        if (mImageUri != null) {
            final StorageReference fileReference = mStorageRef.child(System.currentTimeMillis() +
                    "." + getFileExtension(mImageUri));

             mUploadtask = fileReference.putFile(mImageUri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot)
                        {
                            fileReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(final Uri uri) {
                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            dialog.setProgress(0);
                                            pb.setProgress(0);
                                        }
                                    }, 500);

                                    Toast.makeText(ImagePickingActivity.this, "Uploaded successful", Toast.LENGTH_SHORT).show();


                                    databaseReference.addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(DataSnapshot dataSnapshot) {
                                            // This method is called once with the initial value and again
                                            // whenever data at this location is updated.
                                            String  value = dataSnapshot.getValue(String.class);


                                            if (value != null){
                                                Upload upload = new Upload( value + ": "+mEditText_FileName.getText().toString().trim(),
                                                        uri.toString());
                                                String uploadid=mDatabaseRef.push().getKey();
                                                mDatabaseRef.child(uploadid).setValue(upload);
                                                dialog.dismiss();

                                            } else {
                                                Upload upload = new Upload( spUserName + ": "+mEditText_FileName.getText().toString().trim(),
                                                        uri.toString());
                                                String uploadid=mDatabaseRef.push().getKey();
                                                mDatabaseRef.child(uploadid).setValue(upload);
                                                dialog.dismiss();
                                            }
                                        }

                                        @Override
                                        public void onCancelled(DatabaseError error) {
                                            // Failed to read value
                                        }
                                    });




                                   /* Upload upload = new Upload( ": "+mEditText_FileName.getText().toString().trim(),
                                            uri.toString());
                                            */
                            /*String uploadId = mDatabaseRef.push().getKey();
                            mDatabaseRef.child(uploadId).setValue(upload);*/
                                    DatabaseReference sub = mDatabaseRef.push();

                                   /* String uploadid=mDatabaseRef.push().getKey();
                                    mDatabaseRef.child(uploadid).setValue(upload);
                                    dialog.dismiss();*/
                                    finish();
                                   /* Intent i = new Intent(ImagePickingActivity.this,ExpertActivity.class);
                                    startActivity(i);*/

                                }
                            });
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            dialog.dismiss();
                            Toast.makeText(ImagePickingActivity.this, "" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                            dialog.setProgress((int) progress);
                            pb.setProgress((int) progress);
                        }
                    });

        } else {
            Toast.makeText(this, "No File Selected", Toast.LENGTH_SHORT).show();
        }

    }

    private void openFileChooser() {
        Intent i = new Intent();
        i.setType("image/*");
        i.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(i, PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {

            mImageUri = data.getData();

            Picasso.with(this)
                    .load(mImageUri)
                    .placeholder(R.mipmap.ic_launcher)
                    .into(imageView);
            // basic loading of image
            //  imageView.setImageURI(mImageUri);
        }

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        /*Intent i = new Intent(ImagePickingActivity.this,ExpertActivity.class);
        startActivity(i);*/
        finish();
    }
}

