package com.example.agriaiuto.Fragments;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.agriaiuto.Adapters.MerchantAdapter;
import com.example.agriaiuto.Adapters.PesticidesAdapter;
import com.example.agriaiuto.Model.PesticideModel;
import com.example.agriaiuto.UI_Activities.PesticideDetailsActivity;
import com.example.agriaiuto.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class PesticidesFragment extends Fragment {

    RecyclerView rv;
    private String language;
    private DatabaseReference myref;
    ProgressDialog pg;
    private ArrayList<PesticideModel> pesticideArrayList;

    public PesticidesFragment() {
        // Required empty public constructor
    }

    @SuppressLint("ValidFragment")
    public PesticidesFragment(String language) {
        this.language = language;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_pesticides, container, false);
        rv = v.findViewById(R.id.recycler_pesticide_frag);
        pg = new ProgressDialog(getContext());
        pg.setMessage("Pesticide Data Loading...\nPlease Wait");
        pg.show();
        pesticideArrayList = new ArrayList<>();

        rv.setHasFixedSize(true);
        rv.setLayoutManager(new GridLayoutManager(getContext(), 2));
        myref = FirebaseDatabase.getInstance().getReferenceFromUrl("https://agri-aiuto.firebaseio.com/pesticide/"+language);
        myref.keepSynced(true);
        myref.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                Toast.makeText(getContext(), ""+dataSnapshot.getChildrenCount(), Toast.LENGTH_SHORT).show();

                for (DataSnapshot ds:dataSnapshot.getChildren())
                {
                    PesticideModel merchant=ds.getValue(PesticideModel.class);
                    pesticideArrayList.add(merchant);
                }

                rv.setAdapter(new PesticidesAdapter(getContext(),pesticideArrayList));
                pg.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        });


       /* FirebaseRecyclerAdapter<PesticideModel, PesticidesFragment.PesticideInfoViewHolder> recyclerAdapter = new FirebaseRecyclerAdapter<PesticideModel, PesticidesFragment.PesticideInfoViewHolder>(
                PesticideModel.class,
                R.layout.row_pesticide,
                PesticidesFragment.PesticideInfoViewHolder.class,
                myref
        ) {

            @Override
            protected void populateViewHolder(PesticidesFragment.PesticideInfoViewHolder viewHolder, final PesticideModel model, int position) {

                viewHolder.setImage(model.getImageUrl());
                pg.dismiss();
                // Toast.makeText(PesticideActivity.this, "img: "+model.getImageUrl(), Toast.LENGTH_SHORT).show();

                viewHolder.imageView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(getActivity(), PesticideDetailsActivity.class);

                        i.putExtra("pesticideImageKey",model.getImageUrl());
                        i.putExtra("pesticideNameKey",model.getName());
                        i.putExtra("pesticideCostKey",model.getCost());
                        i.putExtra("pesticideDesKey",model.getDescription());
                        i.putExtra("pesticideModeOfActionKey",model.getModeOfAction());
                        i.putExtra("pesticideFeaturesKey",model.getFeatures());
                        i.putExtra("pesticideChemicalsKey",model.getChemicalsUsed());
                        i.putExtra("pesticideHowToUsedKey",model.getHowToUse());
                        i.putExtra("pesticideChemicalsKey",model.getChemicalsUsed());

                        startActivity(i);
                    }
                });
            }
        };
        rv.setAdapter(recyclerAdapter);
       */
       return v;
    }
 /*   public static class PesticideInfoViewHolder extends RecyclerView.ViewHolder {
        View mView;
        ImageView imageView;

        public PesticideInfoViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            imageView = itemView.findViewById(R.id.img_pesticide);
        }


        public void setImage(String image) {
            if (image.isEmpty()) {
                imageView.setImageResource(R.mipmap.ic_launcher);
            } else {
                Picasso.with(mView.getContext())
                        .load(image)
                        .into(imageView);
            }
        }

    }

*/
}
