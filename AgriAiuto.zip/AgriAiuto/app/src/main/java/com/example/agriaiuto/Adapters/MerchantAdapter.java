package com.example.agriaiuto.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.agriaiuto.Model.MerchantModel;
import com.example.agriaiuto.R;
import com.example.agriaiuto.UI_Activities.Details_MechantActivity;

import java.util.ArrayList;

public class MerchantAdapter extends RecyclerView.Adapter<MerchantAdapter.MerchantInfo>
{
    private Context context;
    ArrayList<MerchantModel> merchantInfoArrayList;

    public MerchantAdapter(Context context, ArrayList<MerchantModel> merchantInfoArrayList) {
        this.context = context;
        this.merchantInfoArrayList = merchantInfoArrayList;
    }

    @NonNull
    @Override
    public MerchantInfo onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(context).inflate(R.layout.row_merchant,viewGroup,false);
        return new MerchantInfo(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MerchantInfo merchantInfo, final int pos) {
        merchantInfo.setTitle(merchantInfoArrayList.get(pos).getName());

        merchantInfo.textView_title.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, Details_MechantActivity.class);
                i.putExtra("merchantNameKey",merchantInfoArrayList.get(pos).getName());
                i.putExtra("merchantCotactKey",merchantInfoArrayList.get(pos).getContact());
                i.putExtra("merchantLocationKey",merchantInfoArrayList.get(pos).getLocation());
                i.putExtra("merchantCropListKey",merchantInfoArrayList.get(pos).getCropList());
                Toast.makeText(context, "cropList: "+merchantInfoArrayList.get(pos).getCropList(), Toast.LENGTH_SHORT).show();
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return merchantInfoArrayList.size();
    }

    public class MerchantInfo extends RecyclerView.ViewHolder {

        View mView;
        TextView textView_title;

        public MerchantInfo(View itemView) {
            super(itemView);
            mView = itemView;
            textView_title = itemView.findViewById(R.id.merchantName);
        }

        public void setTitle(String title) {
            textView_title.setText(title + "");

        }

    }
}
