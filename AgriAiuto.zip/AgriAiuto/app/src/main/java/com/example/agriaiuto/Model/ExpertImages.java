package com.example.agriaiuto.Model;

public class ExpertImages
{
    String image_url;
    String comment;

    public ExpertImages() {
    }

    public ExpertImages(String image_url, String comment) {
        this.image_url = image_url;
        this.comment = comment;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
