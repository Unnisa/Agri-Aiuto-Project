package com.example.agriaiuto.Fragments;


import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.agriaiuto.Adapters.CropAdapter;
import com.example.agriaiuto.Model.CropModel;
import com.example.agriaiuto.R;
import com.example.agriaiuto.RoomDb.CropViewModel;

import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class CropFavoritesFragment extends Fragment {

    RecyclerView rv;
    CropViewModel viewModel;
    private CropAdapter adapter;

    public CropFavoritesFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_crop_favorites, container, false);
        rv = v.findViewById(R.id.recy_crop_fav);

        viewModel = ViewModelProviders.of(this).get(CropViewModel.class);

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT){
            rv.setLayoutManager(new GridLayoutManager(getContext(), 2));
        } else {
            rv.setLayoutManager(new GridLayoutManager(getContext(),4));
        }


        viewModel.getLive_list().observe(this, new Observer<List<CropModel>>() {
            @Override
            public void onChanged(@Nullable List<CropModel> movieEntities) {
                adapter = new CropAdapter(getContext(), movieEntities,rv);
                rv.setAdapter(adapter);
            }
        });

        return v;
    }

}
