package com.example.agriaiuto.Model;

public class PesticideModel {
    String chemicalsUsed;
    String description;
    Integer cost;
    String features;
    String howToUse;
    String imageUrl;
    String modeOfAction;
    String name;

    public String getChemicalsUsed() {
        return chemicalsUsed;
    }

    public void setChemicalsUsed(String chemicalsUsed) {
        this.chemicalsUsed = chemicalsUsed;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Integer getCost() {
        return cost;
    }

    public void setCost(Integer cost) {
        this.cost = cost;
    }

    public String getFeatures() {
        return features;
    }

    public void setFeatures(String features) {
        this.features = features;
    }

    public String getHowToUse() {
        return howToUse;
    }

    public void setHowToUse(String howToUse) {
        this.howToUse = howToUse;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getModeOfAction() {
        return modeOfAction;
    }

    public void setModeOfAction(String modeOfAction) {
        this.modeOfAction = modeOfAction;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
