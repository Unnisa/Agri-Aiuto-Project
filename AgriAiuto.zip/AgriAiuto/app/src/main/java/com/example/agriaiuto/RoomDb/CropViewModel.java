package com.example.agriaiuto.RoomDb;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.ViewModel;
import android.support.annotation.NonNull;

import com.example.agriaiuto.Model.CropModel;

import java.util.List;

public class CropViewModel extends AndroidViewModel
{
    private CropRepository mCropRepository;
    private LiveData<List<CropModel>> live_list;
    private List<CropModel> cropList;

    public CropViewModel(@NonNull Application application)
    {
        super(application);
        mCropRepository = new CropRepository(application);
        live_list = mCropRepository.getmAllCropData();
        cropList = mCropRepository.getCropList();
    }

    public LiveData<List<CropModel>> getLive_list() {
        return live_list;
    }

    public List<CropModel> getCropList() {
        return cropList;
    }

    public void insert(CropModel cropEntity) {
        mCropRepository.insert(cropEntity);
    }

    public void delete(CropModel cropEntity) {
        mCropRepository.delete(cropEntity);
    }

}
