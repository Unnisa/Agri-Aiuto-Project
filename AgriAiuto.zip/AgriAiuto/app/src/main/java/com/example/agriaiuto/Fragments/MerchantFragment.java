package com.example.agriaiuto.Fragments;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.agriaiuto.Adapters.MerchantAdapter;
import com.example.agriaiuto.UI_Activities.MerchantRegisterActivity;
import com.example.agriaiuto.Model.MerchantModel;
import com.example.agriaiuto.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class MerchantFragment extends Fragment {
    RecyclerView rv;
    private String language;
    private DatabaseReference myref;
    ProgressDialog pg;
    ArrayList<MerchantModel> merchantArrayList;

    @SuppressLint("ValidFragment")
    public MerchantFragment(String language) {
        this.language = language;
    }

    public MerchantFragment() {
        // Required empty public constructor
    }


    @SuppressLint("NewApi")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       View v = inflater.inflate(R.layout.fragment_merchant, container, false);
        rv = v.findViewById(R.id.recycler_merchant_frag);
        pg = new ProgressDialog(getContext());
        pg.setMessage("Merchant Data Loading...\nPlease Wait");
        pg.show();

        merchantArrayList = new ArrayList<>();

       // FirebaseDatabase.getInstance().setPersistenceEnabled(true);


        FloatingActionButton fab = v.findViewById(R.id.fab_frag);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getActivity(), MerchantRegisterActivity.class);
                startActivity(i);
            }
        });

       // language = Objects.requireNonNull(getActivity()).getIntent().getStringExtra("KEY");

        rv.setHasFixedSize(true);
        rv.setLayoutManager(new LinearLayoutManager(getContext()));
        myref = FirebaseDatabase.getInstance().getReferenceFromUrl("https://agri-aiuto.firebaseio.com/merchant/"+language);
        myref.keepSynced(true);

        myref.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                Toast.makeText(getContext(), ""+dataSnapshot.getChildrenCount(), Toast.LENGTH_SHORT).show();

                for (DataSnapshot ds:dataSnapshot.getChildren())
                {
                    MerchantModel merchant=ds.getValue(MerchantModel.class);
                    merchantArrayList.add(merchant);
                }

                rv.setAdapter(new MerchantAdapter(getContext(),merchantArrayList));
                pg.dismiss();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        });


       /* FirebaseRecyclerAdapter<MerchantModel, MerchantFragment.MerchantInfoViewHolder> recyclerAdapter = new FirebaseRecyclerAdapter<MerchantModel, MerchantFragment.MerchantInfoViewHolder>(
                MerchantModel.class,
                R.layout.row_merchant,
                MerchantFragment.MerchantInfoViewHolder.class,
                myref
        ) {

            @Override
            protected void populateViewHolder(MerchantFragment.MerchantInfoViewHolder viewHolder, final MerchantModel model, int position) {
                viewHolder.setTitle(model.getName());
                pg.dismiss();
                viewHolder.textView_title.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent i = new Intent(getContext(), Details_MechantActivity.class);
                        i.putExtra("merchantNameKey",model.getName());
                        i.putExtra("merchantCotactKey",model.getContact());
                        i.putExtra("merchantLocationKey",model.getLocation());
                        i.putExtra("merchantCropListKey",model.getCropList());
                        Toast.makeText(getActivity(), "cropList: "+model.getCropList(), Toast.LENGTH_SHORT).show();
                        startActivity(i);
                    }
                });
            }
        };
       */
        //rv.setAdapter(recyclerAdapter);
        return  v;
    }
  /*  public static class MerchantInfoViewHolder extends RecyclerView.ViewHolder {
        View mView;
        TextView textView_title;

        public MerchantInfoViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
            textView_title = itemView.findViewById(R.id.merchantName);
        }

        public void setTitle(String title) {
            textView_title.setText(title + "");

        }

    }*/
}
