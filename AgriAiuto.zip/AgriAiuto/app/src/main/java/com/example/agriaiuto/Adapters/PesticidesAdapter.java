package com.example.agriaiuto.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.agriaiuto.Model.PesticideModel;
import com.example.agriaiuto.R;
import com.example.agriaiuto.UI_Activities.PesticideDetailsActivity;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class PesticidesAdapter extends RecyclerView.Adapter<PesticidesAdapter.PestiInfo>
{
    private Context context;
    ArrayList<PesticideModel> pesticideModelArrayList;

    public PesticidesAdapter(Context context, ArrayList<PesticideModel> pesticideModelArrayList)
    {
        this.context = context;
        this.pesticideModelArrayList = pesticideModelArrayList;
    }

    @NonNull
    @Override
    public PestiInfo onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(context).inflate(R.layout.row_pesticide,viewGroup,false);
        return new PestiInfo(v);
    }

    @Override
    public void onBindViewHolder(@NonNull PestiInfo pestiInfo, final int pos) {
        pestiInfo.setImage(pesticideModelArrayList.get(pos).getImageUrl());

        // Toast.makeText(PesticideActivity.this, "img: "+model.getImageUrl(), Toast.LENGTH_SHORT).show();

        pestiInfo.imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(context, PesticideDetailsActivity.class);

                i.putExtra("pesticideImageKey",pesticideModelArrayList.get(pos).getImageUrl());
                i.putExtra("pesticideNameKey",pesticideModelArrayList.get(pos).getName());
                i.putExtra("pesticideCostKey",pesticideModelArrayList.get(pos).getCost());
                i.putExtra("pesticideDesKey",pesticideModelArrayList.get(pos).getDescription());
                i.putExtra("pesticideModeOfActionKey",pesticideModelArrayList.get(pos).getModeOfAction());
                i.putExtra("pesticideFeaturesKey",pesticideModelArrayList.get(pos).getFeatures());
                i.putExtra("pesticideChemicalsKey",pesticideModelArrayList.get(pos).getChemicalsUsed());
                i.putExtra("pesticideHowToUsedKey",pesticideModelArrayList.get(pos).getHowToUse());
                i.putExtra("pesticideChemicalsKey",pesticideModelArrayList.get(pos).getChemicalsUsed());

                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return pesticideModelArrayList.size();
    }

    public class PestiInfo extends RecyclerView.ViewHolder {

        View mView;
        ImageView imageView;

        public PestiInfo(View itemView) {
            super(itemView);
            mView = itemView;
            imageView = itemView.findViewById(R.id.img_pesticide);
        }


        public void setImage(String image) {
            if (image.isEmpty()) {
                imageView.setImageResource(R.mipmap.ic_launcher);
            } else {
                Picasso.with(mView.getContext())
                        .load(image)
                        .into(imageView);
            }
        }

    }
}
