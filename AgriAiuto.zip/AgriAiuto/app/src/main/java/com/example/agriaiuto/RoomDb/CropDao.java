package com.example.agriaiuto.RoomDb;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import com.example.agriaiuto.Model.CropModel;

import java.util.List;

@Dao
public interface CropDao
{
    @Insert
    void saveAsFavourites(CropModel cropModel);

    @Query("select * from CropModel")
    List<CropModel> readAllData();

    @Query("select * from CropModel")
    LiveData<List<CropModel>> readAllData_liveData();


    @Delete
    void removeFromFavourites(CropModel cropModel);

}
