package com.example.agriaiuto.Model;

public class ExpertModel
{
    String name;
    String profile_img;
    String contact;
    String email;
    String course;

    public ExpertModel(String name, String profile_img, String contact, String email, String course)
    {
        this.name = name;
        this.profile_img = profile_img;
        this.contact = contact;
        this.email = email;
        this.course = course;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProfile_img() {
        return profile_img;
    }

    public void setProfile_img(String profile_img) {
        this.profile_img = profile_img;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }
}
