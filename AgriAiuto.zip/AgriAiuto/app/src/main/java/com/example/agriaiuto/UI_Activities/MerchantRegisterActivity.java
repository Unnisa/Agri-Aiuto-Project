package com.example.agriaiuto.UI_Activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.agriaiuto.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MerchantRegisterActivity extends AppCompatActivity {

    TextInputEditText et_name,et_contact,et_location,et_cropList;
    private DatabaseReference myref;
    ProgressDialog pg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_merchant_register);
        et_name = findViewById(R.id.et_merchantName);
        et_contact = findViewById(R.id.et_merchantContact);
        et_location = findViewById(R.id.et_merchantLocation);
        et_cropList = findViewById(R.id.et_cropList);
        pg = new ProgressDialog(this);
        pg.setMessage("Uploading into RealTime Database\nPlease wait...");

        myref = FirebaseDatabase.getInstance().getReferenceFromUrl("https://agri-aiuto.firebaseio.com/merchant/telugu");

        setTitle("Merchant Registration");
    }

    public void saveMerchant(View view)
    {
        int itemCount = 18;
        String name = et_name.getText().toString().trim();
        String contact = et_contact.getText().toString().trim();
        String location = et_location.getText().toString().trim();
        String cropList = et_cropList.getText().toString().trim();
        if (name.length()!= 0 && contact.length()==10 && location.length()!=0 && cropList.length() !=0)
        {
            itemCount++;
            myref = myref.child(""+itemCount).push();
            myref.child("contact").setValue(contact);
            myref.child("name").setValue(name);
            myref.child("location").setValue(location);
            myref.child("cropsList").setValue(cropList);
            Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show();
            pg.dismiss();

            et_name.setText(null);
            et_contact.setText(null);
            et_location.setText(null);
            et_cropList.setText(null);
            finish();
        }else
         {
             Toast.makeText(this, "Please enter data properly", Toast.LENGTH_SHORT).show();
         }

    }
}
