package com.example.agriaiuto.UI_Activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import com.example.agriaiuto.R;

public class LanguagesActivity extends AppCompatActivity {

    SharedPreferences sp;
    private static final String spFile ="com.example.agriaiuto.UI_Activities.spFile";
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_languages);

      /*  sp = getSharedPreferences(spFile,MODE_PRIVATE);

        editor = sp.edit();
        */
    }

    public void hindiTo(View view) {
        Intent intent = new Intent(this, HomePage.class);
       // Intent intent = new Intent(this, CropActivity.class);
        intent.putExtra("KEY","hindi");
        /*editor.putString("languageKey","hindi");
        editor.commit();
        */
        startActivity(intent);

    }

    public void teluguTo(View view)
    {
       Intent intent = new Intent(this, HomePage.class);
       // Intent intent = new Intent(this, CropActivity.class);
        intent.putExtra("KEY","telugu");
        /*editor.putString("languageKey","hindi");
        editor.commit();
        */
        startActivity(intent);
    }

    public void englishTo(View view) {
        Intent intent = new Intent(this, HomePage.class);
        //Intent intent = new Intent(this, CropActivity.class);
        intent.putExtra("KEY","english");
       /*
        editor.putString("languageKey","hindi");
        editor.commit();
        */
        startActivity(intent);

    }
}
