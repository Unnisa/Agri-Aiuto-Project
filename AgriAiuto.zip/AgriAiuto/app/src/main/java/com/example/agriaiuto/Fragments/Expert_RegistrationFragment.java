package com.example.agriaiuto.Fragments;


import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputEditText;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.example.agriaiuto.Model.ExpertModel;
import com.example.agriaiuto.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import static android.app.Activity.RESULT_OK;

/**
 * A simple {@link Fragment} subclass.
 */
public class Expert_RegistrationFragment extends Fragment {
    TextInputEditText et_name, et_contact, et_email;
    Spinner sp;
    Button pickImg, sendImg, save_Expert_Details;

    String name, contact, email, course;
    private ProgressDialog dialog;

    private StorageReference sRef;
    private DatabaseReference dRef;
    private StorageTask mUploadtask;
    private int req_code = 1;
    private Uri uriImg;


    public Expert_RegistrationFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_expert__registration, container, false);

        et_name = v.findViewById(R.id.et_expertName);
        et_contact = v.findViewById(R.id.et_expertContact);
        et_email = v.findViewById(R.id.et_email_expert);
        sp = v.findViewById(R.id.spinner_course);
        pickImg = v.findViewById(R.id.pickImage_expert_Reg);
       // sendImg = v.findViewById(R.id.upload_img_expert_Reg);
        save_Expert_Details = v.findViewById(R.id.save_expert_details);

        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                course = (String) parent.getItemAtPosition(position);
                // Notify the selected item text
                Toast.makeText
                        (getContext(), "Selected course : " + course, Toast.LENGTH_SHORT)
                        .show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        dialog = new ProgressDialog(getContext());
        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        dialog.setTitle("Expert Profile Uploading...");
        dialog.setMessage("please wait");

        sRef = FirebaseStorage.getInstance().getReference("Expert_Images");
        dRef = FirebaseDatabase.getInstance().getReference("Expert_Profile_Data");
        save_Expert_Details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mUploadtask != null && mUploadtask.isInProgress()) {
                    dialog.show();
                    Toast.makeText(getContext(), "UPLOAD IN PROGRESS", Toast.LENGTH_SHORT).show();
                } else {
                    dialog.show();
                    uploadImage();

                }
            }
        });
        pickImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooserImg();

                if (uriImg != null) {
                    pickImg.setText("Image Selected");
                }
            }
        });


        return v;
    }

    private void chooserImg() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, req_code);

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode,
                                 @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == req_code && resultCode == RESULT_OK && data != null && data.getData() != null) {
            uriImg = data.getData();
            Toast.makeText(getContext(), "Image Selected", Toast.LENGTH_SHORT).show();

            // Picasso.with(getContext()).load(imageurl).into(imageView);
        }

    }

    private String getFileExtention(Uri uri) {
        ContentResolver contentResolver = getActivity().getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }


    private void uploadImage() {
        name = et_name.getText().toString().trim();
        email =  et_email.getText().toString().trim();
        contact = et_contact.getText().toString().trim();

        if (uriImg != null & name !=null & email !=null & contact !=null ) {

            final StorageReference reference = sRef.child(System.currentTimeMillis() + "." + getFileExtention(uriImg));


            mUploadtask = reference.putFile(uriImg).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    reference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            Handler handler = new Handler();
                            handler.postDelayed(new Runnable() {
                                @Override
                                public void run() {

                                    dialog.setProgress(0);
                                }
                            }, 500);
                            Toast.makeText(getContext(), "Image Uploaded Successfully", Toast.LENGTH_SHORT).show();

                            ExpertModel upload = new ExpertModel(et_name.getText().toString().trim(), uri.toString(),
                                    et_contact.getText().toString().trim(), et_email.getText().toString().trim(),course);

                            String uploadid = dRef.push().getKey();
                            dRef.child(uploadid).setValue(upload);
                            dialog.dismiss();

                            resetForNewExpert();

                        }
                    });


                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    dialog.dismiss();
                    Toast.makeText(getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                    double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
                    dialog.setProgress((int) progress);
                }
            });

        } else {
            Toast.makeText(getContext(), "Please fill the Expert Name, Contact,Email \n Select Course and No Image file selected", Toast.LENGTH_SHORT).show();
        }

    }

    private void resetForNewExpert()
    {
        et_email.setText(null);
        et_contact.setText(null);
        et_name.setText(null);
        uriImg =null;
    }

}
