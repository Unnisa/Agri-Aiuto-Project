package com.example.agriaiuto.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.agriaiuto.Model.Upload;
import com.example.agriaiuto.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class AdviseExpertAdapter extends RecyclerView.Adapter<AdviseExpertAdapter.AdviseExperInfo>
{
    private Context context;
    private ArrayList<Upload> uploadArrayList;
    String mAuth_currentUserName;

    public AdviseExpertAdapter(Context context, ArrayList<Upload> uploadArrayList, String mAuth_currentUserName)
    {
        this.context = context;
        this.uploadArrayList = uploadArrayList;
        this.mAuth_currentUserName = mAuth_currentUserName;
    }

    @NonNull
    @Override
    public AdviseExperInfo onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(context).inflate(R.layout.row_image_expert,viewGroup,false);
        return new AdviseExperInfo(v);
    }

    @Override
    public void onBindViewHolder(@NonNull final AdviseExperInfo adviseExperInfo, final int i) {
        adviseExperInfo.setImage(uploadArrayList.get(i).getmImageUrl());
        adviseExperInfo.setTitle(uploadArrayList.get(i).getComment());
        adviseExperInfo.sendComment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                final String new_comment = adviseExperInfo.editText.getText().toString().trim();
                String comment = uploadArrayList.get(i).getComment()+"\n"+mAuth_currentUserName+":"+new_comment;
                uploadArrayList.get(i).setComment(comment);

                adviseExperInfo.setTitle(uploadArrayList.get(i).getComment());
                adviseExperInfo.editText.setText(null);
              //  ExpertActivity expertActivity = new ExpertActivity(context,uploadArrayList);
            }
        });
    }
    @Override
    public int getItemCount() {
        return uploadArrayList.size();
    }

    public class AdviseExperInfo extends RecyclerView.ViewHolder {
        View mView;
        TextView textView_title;
        ImageView imageView,sendComment;
        EditText editText;
        public AdviseExperInfo(@NonNull View itemView)
        {
            super(itemView);

            mView=itemView;
            textView_title = itemView.findViewById(R.id.tv_commented_data);
            imageView=itemView.findViewById(R.id.img_uploaded_expert);
            editText = itemView.findViewById(R.id.et_expert);
            sendComment = itemView.findViewById(R.id.sendComment);

        }

        public void setTitle(String title)
        {
            textView_title.setText(title+"");
        }

        public void setImage(String image)
        {
            Picasso.with(mView.getContext())
                    .load(image)
                    .placeholder(R.mipmap.ic_launcher)
                    .into(imageView);
        }
    }
}
