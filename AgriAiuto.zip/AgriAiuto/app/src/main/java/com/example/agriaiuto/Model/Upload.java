package com.example.agriaiuto.Model;

public class Upload
{
    private String comment;
    private String mImageUrl;

    public Upload() {
    }

    public Upload(String comment, String mImageUrl) {
        this.comment = comment;
        this.mImageUrl = mImageUrl;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getmImageUrl() {
        return mImageUrl;
    }

    public void setmImageUrl(String mImageUrl) {
        this.mImageUrl = mImageUrl;
    }

}
