package com.example.agriaiuto.UI_Activities;

import android.arch.lifecycle.ViewModelProviders;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.agriaiuto.Model.CropModel;
import com.example.agriaiuto.R;
import com.example.agriaiuto.RoomDb.CropViewModel;
import com.github.ivbaranov.mfb.MaterialFavoriteButton;
import com.squareup.picasso.Picasso;

import java.util.List;

public class Crop_DetailsActivity extends AppCompatActivity {

    MaterialFavoriteButton fav_btn;
    TextView tv_seedName,tv_soilType,tv_season,tv_temperature,tv_description,tv_amountOfWater,tv_pesticides;

    ImageView img;
    String amountOfWater,description,imageLink,name,pesticides,season,soilType,temperature;

    CropViewModel mCropViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crop__details);
        fav_btn = findViewById(R.id.fav_icon);

       // mCropViewModel = ViewModelProviders.of(this).get(CropViewModel.class);
        mCropViewModel = ViewModelProviders.of(this).get(CropViewModel.class);

        tv_amountOfWater = findViewById(R.id.tv_amountofWater_id_cropDetails);
        tv_description = findViewById(R.id.tv_description_id_cropDetails);
        img = findViewById(R.id.img_cropDetails);
        tv_seedName = findViewById(R.id.tv_seedName_Id_cropDetails);
        tv_pesticides = findViewById(R.id.tv_pesticidesUsed_id_cropDetails);
        tv_season = findViewById(R.id.tv_seasontype_id_cropDetails);
        tv_soilType = findViewById(R.id.tv_soiltype_id_cropDetails);
        tv_temperature = findViewById(R.id.tv_temp_id_cropDetails);

        amountOfWater = getIntent().getStringExtra("amountOfWaterKey");
        description = getIntent().getStringExtra("desKey");
        imageLink = getIntent().getStringExtra("imageLinkKey");
        name = getIntent().getStringExtra("nameKey");
        pesticides = getIntent().getStringExtra("pesticidesKey");
        season = getIntent().getStringExtra("seasonKey");
        soilType = getIntent().getStringExtra("soilTypeKey");
        temperature = getIntent().getStringExtra("temperatureKey");

        tv_amountOfWater.setText(amountOfWater);
        tv_seedName.setText(name);
        if(description !=null)
        {
            tv_description.setText(description);
        }
        else
            {
                tv_description.setText("No Description available");
            }
        tv_soilType.setText(soilType);
        tv_season.setText(season);
        tv_temperature.setText(temperature);
        tv_pesticides.setText(pesticides);
        if (imageLink.isEmpty()){
            img.setImageResource(R.mipmap.ic_launcher);
        }
        {
            Picasso.with(this)
                    .load(imageLink)
                    .placeholder(R.mipmap.ic_launcher)
                    .into(img);
        }


        List<CropModel> cropList = mCropViewModel.getCropList();

        Log.i("mylog","available size:"+cropList.size());
        if (cropList.size()>0) {
            for (int i1 = 0; i1 < cropList.size(); i1++) {
                if (cropList.get(i1).getName() .equals( name)) {
                     fav_btn.setFavorite(true);
                    Log.i("mylog:","availabel");
                }
            }
        }
        fav_btn.setOnFavoriteChangeListener(new MaterialFavoriteButton.OnFavoriteChangeListener() {
            @Override
            public void onFavoriteChanged(MaterialFavoriteButton buttonView, boolean favorite) {

                if (favorite) {
                    mCropViewModel.insert(setValuesToEntity());

                    Snackbar.make(buttonView, "Added as Favorite",
                            Snackbar.LENGTH_SHORT).show();
                } else {

                    mCropViewModel.delete(setValuesToEntity());
                    Snackbar.make(buttonView, "Removed from Favorite",
                            Snackbar.LENGTH_SHORT).show();
                }
            }
        });



    }

    private CropModel setValuesToEntity()
    {
        CropModel cropModel = new CropModel();
        cropModel.setAmountOfWater(amountOfWater);
        cropModel.setDescrption(description);
        cropModel.setImageLink(imageLink);
        cropModel.setName(name);
        cropModel.setPesticides(pesticides);
        cropModel.setSeason(season);
        cropModel.setSoilType(soilType);
        cropModel.setTemperature(temperature);
        return cropModel;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}
