package com.example.agriaiuto.UI_Activities;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.ShareCompat;
import android.support.v7.app.AlertDialog;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.example.agriaiuto.CheckInternet.InternetConnection;
import com.example.agriaiuto.Fragments.CropFavoritesFragment;
import com.example.agriaiuto.Fragments.CropFragment;
import com.example.agriaiuto.Fragments.ExpertFragment;
import com.example.agriaiuto.Fragments.Expert_RegistrationFragment;
import com.example.agriaiuto.Fragments.FeedbackFragment;
import com.example.agriaiuto.Fragments.MerchantFragment;
import com.example.agriaiuto.Fragments.PesticidesFragment;
import com.example.agriaiuto.Fragments.SeasonFragment;
import com.example.agriaiuto.R;
import com.example.agriaiuto.activities.MainScreenActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class HomePage extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {
    FirebaseAuth mAuth;
    String language;
    String spUserName;
    SharedPreferences sp;
    private static final String spFile = "com.example.agriaiuto.UI_Activities.spFile";

    private TextView header_Email,header_UserName;
    private DatabaseReference user_name_ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        mAuth = FirebaseAuth.getInstance();
        language = getIntent().getStringExtra("KEY");

        sp = getSharedPreferences(spFile,MODE_PRIVATE);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View header = navigationView.getHeaderView(0);
        header_UserName = header.findViewById(R.id.header_tv_userName_id);
        header_Email = header.findViewById(R.id.header_tv_email_id);

        header_UserName.setText(spUserName);

        checkInternet();
    }

    @SuppressLint("NewApi")
    private void checkInternet() {
        if (InternetConnection.isNetworkAvailable(this))
        {
            Toast.makeText(this, "Internet Connected", Toast.LENGTH_SHORT).show();
            header_Email.setText(Objects.requireNonNull(mAuth.getCurrentUser()).getEmail());
           /* FirebaseDatabase.getInstance().getReference().child("AgriAuito_users")
                    .child(mAuth.getCurrentUser().getUid()).child("name");
            user_name_ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    String userName_firebase = Objects.requireNonNull(dataSnapshot.getValue()).toString();
                    header_UserName.setText(userName_firebase);
                    header_UserName.setAllCaps(true);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
           */
           displayFragments(R.id.nav_crop);

        } else {
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
            builder.setTitle("No Internet Permissions");
            builder.setMessage("need Internet permissions!");
            builder.setIcon(R.drawable.ic_sentiment_dissatisfied_black_24dp);
            builder.setPositiveButton("Go to Settings", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Intent i = new Intent(Settings.ACTION_WIRELESS_SETTINGS);
                    startActivity(i);
                }
            });
            builder.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();

                }
            });
            builder.show();
        }

    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_page, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.


        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        displayFragments(id);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);

        return true;
    }

    private void displayFragments(int id) {
        Fragment fragment = null;
        switch (id) {
            case R.id.nav_crop:
                fragment = new CropFragment(language);
               /* Intent intent = new Intent(this, CropActivity.class);
                intent.putExtra("KEY",language);
                startActivity(intent);*/
                break;
            case R.id.nav_merch:
                fragment = new MerchantFragment(language);
                /*
                Intent intent1 = new Intent(this, MerchantActivity.class);
                intent1.putExtra("KEY",language);
                startActivity(intent1);
                */
                break;
            case R.id.nav_season:
               Intent intent=new Intent(this, MainScreenActivity.class);
               startActivity(intent);
                break;
            case R.id.nav_pest:
                fragment = new PesticidesFragment(language);
                /*Intent intent2 = new Intent(this, PesticideActivity.class);
                intent2.putExtra("KEY",language);
                startActivity(intent2);
                */
                break;
            case R.id.nav_advice:
                //fragment = new AdviceFragment();
                fragment = new ExpertFragment();
               //Intent i3 = new Intent(this, ChatingActivity.class);
               /* Intent i3 = new Intent(this, ExpertActivity.class);
                startActivity(i3);
                */
                break;
            case R.id.nav_expert_profile:
                fragment = new Expert_RegistrationFragment();
                break;
            case R.id.nav_favorites:
                fragment = new CropFavoritesFragment();
                break;

            case R.id.nav_feedBack:
                fragment = new FeedbackFragment();
                break;
            case R.id.nav_share:
                DatabaseReference apk_ref = FirebaseDatabase.getInstance().getReference().child("AgriAuito_APK").child("APK");
                apk_ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                        @SuppressLint({"NewApi", "LocalSuppress"}) String apk_firebase_db = Objects.requireNonNull(dataSnapshot.getValue()).toString();
                        shareAPK(apk_firebase_db);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });



                break;
            case R.id.nav_log_out:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);
                builder.setMessage("Do You Want To Logout?").setTitle("Logout");

                builder.setMessage("Do You Want To Logout?")
                        .setCancelable(false)
                        .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                mAuth.signOut();
                                Intent i = new Intent(getApplicationContext(), LoginActivity.class);
                                startActivity(i);
                                finish();

                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alertDialog = builder.create();
                alertDialog.setTitle("Logout");
                alertDialog.show();
                break;

        }

        if (fragment != null) {
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container,
                    fragment).commit();
        }

    }

    private void shareAPK(String apk_firebase_db) {
        Intent shareIntent = ShareCompat.IntentBuilder.from(this)
                .setType("text/plain")
                .setText("Agri Auito APK link bellow " + "\n" + apk_firebase_db + "\n Thak you Agri Auito Team")
                .getIntent();
        if (shareIntent.resolveActivity(getPackageManager()) != null) {
            startActivity(shareIntent);
        }
    }}
