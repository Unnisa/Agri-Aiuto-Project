package com.example.agriaiuto.UI_Activities;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.example.agriaiuto.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    TextInputEditText et_mail,et_pass;
    FirebaseAuth mAuth;
    protected FirebaseAuth.AuthStateListener mAuthListener;
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et_mail= findViewById(R.id.et_email);
        et_pass = findViewById(R.id.et_password);
        progressBar = findViewById(R.id.progress_login);
        mAuth=FirebaseAuth.getInstance();
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if (firebaseAuth.getCurrentUser()!=null){
                    startActivity(new Intent(getApplicationContext(),LanguagesActivity.class)
                            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK));
                    finish();
                }
            }
        };

    }
    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }


    public void login(View view) {
        userLogin();
    }

    private void userLogin() {
        String reg_mail = et_mail.getText().toString().trim();
        String reg_pass = et_pass.getText().toString().trim();


        if (reg_mail.isEmpty()){
            et_mail.setError("Email ID Must Be Given");
            et_mail.requestFocus();
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(reg_mail).matches()) {
            et_mail.setError("Please Enter a Valid Email");
            et_mail.requestFocus();
            return;
        }
        if (reg_pass.isEmpty()){
            et_pass.setError("Password Must Not Be Empty");
            et_pass.requestFocus();
        }

        if (reg_pass.length() >= 6) {
            et_pass.setError("Password Length at least 6 digits");
            et_pass.requestFocus();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        if(reg_mail.length() !=0 && reg_pass.length() >=6) {
            mAuth.signInWithEmailAndPassword(reg_mail, reg_pass)
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            Intent i = new Intent(getApplicationContext(), LanguagesActivity.class);
                            startActivity(i);
                            progressBar.setVisibility(View.GONE);
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getApplicationContext(), "please Enter Correct Credentials", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }


    public void register(View view) {
        Intent i = new Intent(this, RegisterActivity.class);
        startActivity(i);
    }
}
