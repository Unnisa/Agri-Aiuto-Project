package com.example.agriaiuto.UI_Activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.agriaiuto.R;

public class Details_MechantActivity extends AppCompatActivity {
    TextView tv_Merchant_Name,tv_Merchant_contact,tv_Merchant_location,tv_Merchant_CropList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deatails__mechant);

        tv_Merchant_Name = findViewById(R.id.tv_mechant_name_deatails);
        tv_Merchant_contact = findViewById(R.id.tv_mechant_contact_deatails);
        tv_Merchant_location = findViewById(R.id.tv_mechant_location_deatails);
        tv_Merchant_CropList = findViewById(R.id.tv_mechant_croplist_deatails);

        String name = getIntent().getStringExtra("merchantNameKey");
        String contact = getIntent().getStringExtra("merchantCotactKey");
        String location = getIntent().getStringExtra("merchantLocationKey");
        String cropList = getIntent().getStringExtra("merchantCropListKey");

        tv_Merchant_Name.setText(name);
        tv_Merchant_contact.setText(contact);
        tv_Merchant_location.setText(location);
        tv_Merchant_CropList.setText(cropList);

    }
}
