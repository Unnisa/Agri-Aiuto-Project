package com.example.agriaiuto.Fragments;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.agriaiuto.Adapters.AdviseExpertAdapter;
import com.example.agriaiuto.UI_Activities.ImagePickingActivity;
import com.example.agriaiuto.Model.Upload;
import com.example.agriaiuto.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 */
public class ExpertFragment extends Fragment {

    RecyclerView recyclerView;
    private DatabaseReference myref;

    FloatingActionButton fab;

    FirebaseAuth mAuth;
    private DatabaseReference databaseReference;
    String mAuth_currentUserName;

    String spUserName;
    SharedPreferences sp;
    private static final String spFile = "com.example.agriaiuto.UI_Activities.spFile";

    private DatabaseReference mDatabaseRef;
    private Context context;
    private ArrayList<Upload> uploadArrayList;

    public ExpertFragment() {
        // Required empty public constructor
    }


    @SuppressLint("NewApi")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_expert, container, false);
        recyclerView = v.findViewById(R.id.recycler_expert_frag);
        fab = v.findViewById(R.id.fab_expert_frag);

        uploadArrayList=new ArrayList<>();

        if (sp != null)
        {
            spUserName = sp.getString("uNameKey","a");
        }

        mAuth=FirebaseAuth.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("AgriAuito_users")
                .child(Objects.requireNonNull(mAuth.getCurrentUser()).getUid()).child("name");


        mDatabaseRef = FirebaseDatabase.getInstance().getReferenceFromUrl("https://agri-aiuto.firebaseio.com/uploads");


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(getContext(), ImagePickingActivity.class);
                startActivity(i);
            }
        });

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        myref= FirebaseDatabase.getInstance().getReferenceFromUrl("https://agri-aiuto.firebaseio.com/uploads");
        myref.keepSynced(true);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mAuth_currentUserName = dataSnapshot.getValue(String.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        myref.addValueEventListener(new ValueEventListener()
        {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot)
            {
                Toast.makeText(getContext(), ""+dataSnapshot.getChildrenCount(), Toast.LENGTH_SHORT).show();

                for (DataSnapshot ds:dataSnapshot.getChildren())
                {
                    Upload upload=ds.getValue(Upload.class);
                    uploadArrayList.add(upload);
                }

                recyclerView.setAdapter(new AdviseExpertAdapter(getContext(),uploadArrayList,mAuth_currentUserName));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError)
            {

            }
        });

        return v;

    }
}
