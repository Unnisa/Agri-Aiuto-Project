package com.example.agriaiuto.Model;

public class MerchantModel
{
    String contact;
    String cropList;
    String location;
    String name;

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getCropList() {
        return cropList;
    }

    public void setCropList(String cropList) {
        this.cropList = cropList;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
